#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>
#include<sys/wait.h>

int main(){
	char string[] = "Hello world";
	for(int i =0; i<strlen(string); ++i){
		if(fork() == 0){
			printf("%c : %d\n",string[i], (int) getpid());
			sleep(1+(rand() % 4));
		}		
		else{
			wait(NULL);
			exit(0);
		}
	}
	return 0;
}
