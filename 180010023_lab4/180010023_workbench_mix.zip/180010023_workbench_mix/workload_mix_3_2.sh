#!/bin/sh
./arithoh.sh &
./arithoh.sh &
./fstime.sh &
./fstime.sh &
./arithoh.sh &
wait