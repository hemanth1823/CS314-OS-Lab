#!/bin/sh
./pipe.sh &
./fstime.sh &
./pipe.sh &
./pipe.sh &
./pipe.sh &
wait