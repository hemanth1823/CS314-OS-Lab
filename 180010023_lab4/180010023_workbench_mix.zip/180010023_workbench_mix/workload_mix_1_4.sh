#!/bin/sh
./fstime.sh &
./arithoh.sh &
./fstime.sh &
./fstime.sh &
./fstime.sh &
wait